package ar.org.centro8.curso.java.repositories;

import ar.org.centro8.curso.java.entities.Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class AlumnoR {
    private Connection conn;

    public AlumnoR(Connection conn) {
        this.conn = conn;
    }
    
    public void save(Alumno alumno) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "insert into alumnos (nombre,apellido,edad,idCurso) values (?,?,?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS
            );
            
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.execute();
            
            // Obtengo un ResulSet para sacar la info del PK generado
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) alumno.setId(rs.getInt(1));
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public List<Alumno>getByFiltro(String filtro) {
        return null;
    }
    
}
