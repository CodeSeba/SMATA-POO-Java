use colegio;
select * from alumnos;