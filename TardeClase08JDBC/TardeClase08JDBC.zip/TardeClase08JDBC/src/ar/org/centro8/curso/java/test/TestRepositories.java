package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.conectors.Connector;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.AlumnoR;

public class TestRepositories {
    public static void main(String[] args) {
        AlumnoR ar = new AlumnoR(Connector.getConnection());
        Alumno alumno = new Alumno("Gabriel", "Moreno", 24, 1);
        
        ar.save(alumno);
        System.out.println(alumno);
    }
}
